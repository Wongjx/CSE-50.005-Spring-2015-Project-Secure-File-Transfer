package SecureFileTransfer;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class Client {
	private Socket socket;
	private DataOutputStream clientOutput;
	private DataInputStream clientInput;
	
	private final int PORT=1044;
	private final String HOST="127.0.0.1";
	
	private final String CA_CERT_PATH="C:/Users/Wong/Dropbox/Academics/50.005 Com Systems Engineering/ComSystems/Assigments/src/SecureFileTransfer/CA.crt";
	
	private SecretKey symKey;
	
	private X509Certificate CACert;
	private PublicKey CAkey;
	
	private X509Certificate serverCert;
	private PublicKey publicKey;	
	private Cipher dcipher;
	private Cipher cipher;
	
	
	public static void main(String[] args) {
		Client client = null;
		File fileToSend = new File("path");
		
		try{
			client = new Client() ;
			client.init();
			if(client.sendFile(fileToSend)){
				System.out.println("File transfer succeded");
			}else{
				System.out.println("File transfer failed");
			}
			
		}catch(Exception e){
			System.out.println("Error creating client socket: "+e.getMessage());
		}
	}
	
	public Client() throws UnknownHostException, IOException{
		socket = new Socket(HOST,PORT);
	}
	
	public void init() throws IOException, CertificateException{
		clientOutput=new DataOutputStream(socket.getOutputStream());
		clientInput = new DataInputStream(socket.getInputStream());
		CACert = getX509Cert(CA_CERT_PATH);
		CACert.checkValidity();
		CAkey = CACert.getPublicKey();
	}
	
	public boolean sendFile(File file) throws InvalidKeyException, ClassNotFoundException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, IOException{
		if(startAP()){
			System.out.println("AP succeed!");
			clientOutput.writeInt(1);
			//TODO Encrypt file and send file over
			
			
			
			
			
			
			return true;
		}else{
			System.out.println("Ap failed!");
			clientOutput.writeInt(0);	//AP has failed, close connection
			return false;
		}
	}
	
	/** Encrypt using Server's public key
	 * @param message
	 * @return
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private byte[] encrypt(byte[] message) throws IllegalBlockSizeException, BadPaddingException{
		return cipher.doFinal(message);
	}
	
	/**	Decrypt using Server's public key
	 * @param message
	 * @return
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	private byte[] decrypt(byte[] message) throws IllegalBlockSizeException, BadPaddingException{
		return dcipher.doFinal(message);
	}
	
	
	private X509Certificate getX509Cert(String file) throws CertificateException, IOException {
		 InputStream inStream = null;
		 X509Certificate cert;
		 try {
		     inStream = new FileInputStream(file);
		     CertificateFactory cf = CertificateFactory.getInstance("X.509");
		     cert = (X509Certificate)cf.generateCertificate(inStream);
		 } finally {
		     if (inStream != null) {
		         inStream.close();
		     }
		 }
		 return cert;
	}
	
	private X509Certificate getX509Cert(byte[] input) throws CertificateException, IOException {
		InputStream in = new ByteArrayInputStream(input);
		
		CertificateFactory cf = CertificateFactory.getInstance("X.509");
		X509Certificate cert = (X509Certificate)cf.generateCertificate(in);
		 return cert;
	}
	
	private Cipher getdCipher(PublicKey publicKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException{
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, publicKey);
		 return cipher;
	}
	
	private Cipher getCipher(PublicKey publicKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException{
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		 return cipher;
	}
	
	private void endSeisson(){
		this.symKey=null;
		
	}
	
	/** Start authentication protocol with server
	 * @return boolean: True if AP succeeds; False if AP Fails
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws InvalidKeyException
	 * @throws CertificateException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchProviderException
	 * @throws SignatureException
	 * @throws NoSuchPaddingException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 */
	public boolean startAP() throws IOException, ClassNotFoundException, InvalidKeyException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException{
		//Contact server saying want to start AP for a connection
		
		
		//Generate nonce and send to server
		//Nonce used is symeteric key
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");
		symKey = keyGen.generateKey(); 
		
//		int nonceGen =5;
//		ByteBuffer b = ByteBuffer.allocate(4);
//		b.putInt(nonceGen);
//		byte[] nonceByte = b.array();

//		System.out.println("Sending nonce to server.");			
		byte[] nonce = symKey.getEncoded();						//Send nonce(symkey) to server
//		byte[] nonce = nonceByte;								//Send int nonce to server
		clientOutput.writeInt(nonce.length);
		clientOutput.write(nonce);
//		System.out.println("Message sent to server: "+nonce);
		
		int proofMessageSize=clientInput.readInt();				//Get encrypted nonce from server
		byte[] proofMessage = new byte[proofMessageSize]; 
		clientInput.read(proofMessage);
		
//		System.out.println("Request certificate from server.");	
		byte[] message = "request_cert".getBytes();
		clientOutput.writeInt(message.length);
		clientOutput.write(message);
//		System.out.println("Message sent to server: "+message);
		
//		int certMessageSize=clientInput.readInt();	
//		byte[] certMessage = new byte[certMessageSize]; 
//		clientInput.read(certMessage);
		
		int certMessageSize=clientInput.readInt();				//Get encrypted nonce from server
		byte[] certMessage = new byte[certMessageSize]; 
		clientInput.read(certMessage);
		serverCert=getX509Cert(certMessage);	//Get cert from server
		
		//Verify certificate and get public key from cert
//		System.out.println("Get public key from certificate");
		serverCert.checkValidity();
		serverCert.verify(CAkey);		//Verify server cert against CA key
		publicKey = serverCert.getPublicKey();
		
//		System.out.println("Initialize cipher from server public key");
		dcipher = getdCipher(publicKey); 	//Initialize decrypting cipher
		cipher = getCipher(publicKey);
		
//		System.out.println("Decrypt authentication message");
		byte[] dDataByte = dcipher.doFinal(proofMessage); 	//Decrypt message using public key from CA
		System.out.println("Deciphered Nonce from server: "+Arrays.toString(dDataByte));
		System.out.println("Generated Nonce : "+Arrays.toString(nonce));
		if (Arrays.equals(dDataByte,nonce)){
			return true;
		}
		return false;
	}
}
